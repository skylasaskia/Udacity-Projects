# Ford GoBike Exploration
## by Skyla Ah Shene


## Dataset

> The Ford GoBike data is information concerning bike rides, and we will will only be focusing on the 2019 February dataset.

> It contains the following variables: Trip Duration (seconds) Start Time and Date End Time and Date Start Station ID Start Station Name Start Station Latitude Start Station Longitude End Station ID End Station Name End Station Latitude End Station Longitude Bike ID User Type (Subscriber or Customer – “Subscriber” = Member or “Customer” = Casual)

> source: https://www.lyft.com/bikes/bay-wheels/system-data


## Summary of Findings

> By cleaning and analysing the outcomes and data, I was able to learn and distinguish alot of things about the bike sharing scheme. I was able to see that the males, whether being a subscriber or a random customer, was the gender that made use of the bike sharing scheme the most. We can also assume that the subscribers were regulars who used it throughout the week instead of weekends, to get to work or school or appointments etc, and the non-subscribers might of have only used if it was their last option or for recreational purposes on the weekends, explaining the spike.

## Key Insights for Presentation

> My main topic of research for this dataset is analysing and looking at the relationship between the different genders, subscribers and non-subscribers, and the most popular time of day. With the use of features like member_gender, user_type, bike_share_for_all_trip, start_day_of_week and duration_min alongside many other variables as well.